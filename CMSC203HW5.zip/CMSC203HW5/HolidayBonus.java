package package1;

public class HolidayBonus {

/**
 * Calculates the holiday bonus for each store
 * @param data
 * @param high
 * @param low
 * @param other
 * @return
 */

	public static double[] calculateHolidayBonus(double[][] data, double high, double low, double other) {
		double[][] bonusArr = new double[data.length][];
		for (int i = 0; i < data.length; i++){
			bonusArr[i] = new double[data[i].length];
		}

		for (int i = 0, j = 0; i < bonusArr.length; i++, j++){
			int highestIndex = TwoDimRaggedArrayUtility.getHighestInColumnIndex(data, i);
			int lowestIndex = TwoDimRaggedArrayUtility.getLowestInColumnIndex(data,i);
			if (i < bonusArr[j].length){
				bonusArr[highestIndex][i] = high;
				bonusArr[lowestIndex][i] = low;
				if (j == highestIndex || j == lowestIndex)
					continue;
				else{
					bonusArr[j][i] = other;
				}
			}
		}
		double[] bonusPerStore = new double[data.length];
		for (int i = 0; i < bonusArr.length; i++)
		{
			for (int j = 0; j < bonusArr[i].length; j++)
			{
				bonusPerStore[i] += bonusArr[i][j];
			}
		}
		return bonusPerStore;
}

/**
 * Calculates the total holiday bonuses
 * @param data
 * @param high
 * @param low
 * @param other
 * @return total bonus
 */

public static double calculateTotalHolidayBonus(double[][] data, double high, double low, double other){
	double[][] bonusArr = new double[data.length][];
	for (int i = 0; i < data.length; i++){
		bonusArr[i] = new double[data[i].length];
	}
	for (int i = 0, j = 0; i < bonusArr.length; i++, j++){
		int highestIndex = TwoDimRaggedArrayUtility.getHighestInColumnIndex(data, i);
		int lowestIndex = TwoDimRaggedArrayUtility.getLowestInColumnIndex(data,i);
		if (i < bonusArr[j].length){
				bonusArr[highestIndex][i] = high;
				bonusArr[lowestIndex][i] = low;
			if (j == highestIndex || j == lowestIndex)	
				continue;
			else{
				bonusArr[j][i] = other;
			}
		}
	}
	
	double total = 0;
	for (int i = 0; i < bonusArr.length; i++)
	{
		for (int j = 0; j < bonusArr[i].length; j++)
		{
			total += bonusArr[i][j];
		}
	}
	return total;
	}
}