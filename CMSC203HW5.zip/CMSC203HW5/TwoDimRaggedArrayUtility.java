package package1;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class TwoDimRaggedArrayUtility {
	/**
	 * Returns the average of the elements in the two dimensional array
	 * @param data
	 * @return average of array
	 */
	public static double getAverage(double[][] data) {
	    double total = 0, count = 0;
	    for (int row = 0; row < data.length; row++) {
	        for (int col = 0; col < data[col].length; col++) {
	            total += data[row][col];
	            count++;
	        }
	    }
	    return total / count;
	}
	
	/**
	 *   Returns the total of the selected column in the two dimensional array index 0 refers to the first column.
	 * @param data
	 * @param col
	 * @return Total of selected column
	 */
	public static double getColumnTotal(double[][] data, int col) {
	    double total = 0;
	    for (int row = 0; row < data.length; row++) {
	        total += data[row][col];
	        }
	     return total;
	}
	
	/**
	 * Returns the largest element in the two dimensional array
	 * @param data
	 * @return
	 */
	public static double getHighestInArray(double[][] data) {
	    double highest = data[0][0];
	    for (int row = 0; row < data.length; row++) {
	        for (int col = 0; col < data[row].length; col++) {
	            if (data[row][col] > highest) {
	                highest = data[row][col];
	            }
	        }
	    }
	    return highest;
	}
	
	/**
	 * Returns the largest element of the selected column in the two dimensional array index 0 refers to the first column.
	 * @param data
	 * @param col
	 * @return Highest number in the selected column
	 */
	public static double getHighestInColumn(double[][] data, int col) {
	    double highest = data[0][col];
	    for (int row = 0; row < data.length; row++) {
	        if (col < data[row].length && data[row][col] > highest) {
	            highest = data[row][col];
	        }
	    }
	    return highest;
	}
	
	/**
	 * Returns index of the largest element of the selected column in the two dimensional array index 0 refers to the first column.
	 * @param data
	 * @param col
	 * @return Position in array column where highest number is located
	 */
	public static int getHighestInColumnIndex(double[][] data, int col) {
	    double highest = data[0][col];
	    int highestIndex = 0;
	    for (int row = 0; row < data.length; row++) {
	        if (col < data[row].length && data[row][col] > highest) {         
	            highest = data[row][col];
	            highestIndex = row;
	        }
	    }
	    return highestIndex;
	}
	
	/**
	 *  Returns the largest element of the selected row in the two dimensional array index 0 refers to the first row.
	 * @param data
	 * @param row
	 * @return Highest number in the selected column
	 */ 
	public static double getHighestInRow(double[][] data, int row) {
	    double highest = data[row][0];
	    for (int col = 0; col < data[row].length; col++) {
	        if (data[row][col] > highest) {
	            highest = data[row][col];
	        }
	    }
	    return highest;
	}
	
	/**
	 * Returns the largest element of the selected row in the two dimensional array index 0 refers to the first row.
	 * @param data
	 * @param row
	 * @return Position in array column where highest number is located
	 */
	public static int getHighestInRowIndex(double[][] data, int row) {
	    double highest = data[row][0];
	    int highestIndex = 0;
	    for (int col = 0; col < data[row].length; col++) {
	        if (data[row][col] > highest) {
	            highest = data[row][col];
	            highestIndex = col;
	        }
	    }
	    return highestIndex;
	}
	
	/**
	 * Returns the smallest element in the two dimensional array
	 * @param data
	 * @return Lowest value in 2D array
	 */
	public static double getLowestInArray(double[][] data) {
	    double lowest = data[0][0];
	    for (int row = 0; row < data.length; row++) {
	        for (int col = 0; col < data[row].length; col++) {
	            if (data[row][col] < lowest) {
	                lowest = data[row][col];
	            }
	        }
	    }
	    return lowest;
	}
	
	/**
	 * Returns the smallest element of the selected column in the two dimensional array index 0 refers to the first column.
	 * @param data
	 * @param col
	 * @return Lowest number in selected column of 2D array
	 */
	public static double getLowestInColumn(double[][] data, int col) {
	    double lowest = data[0][col];
	    for (int row = 0; row < data.length; row++) {
	        if (col < data[row].length && data[row][col] < lowest) {
	            lowest = data[row][col];
	        }
	    }
	    return lowest;
	}
	
	/**
	 *  Returns the index of the smallest element of the selected column in the two dimensional array index 0 refers to the first column.
	 * @param data
	 * @param col
	 * @return Position in array column where lowest number is located
	 */
	public static int getLowestInColumnIndex(double[][] data, int col) {
	    double lowest = data[0][col];
	    int lowestIndex = 0;
	    for (int row = 0; row < data.length; row++) {
	        if (col < data[row].length && data[row][col] < lowest) {
	            lowest = data[row][col];
	            lowestIndex = row;
	        }
	    }
	    return lowestIndex;
	}
	
	/**
	 *   Returns the smallest element of the selected row in the two dimensional array index 0 refers to the first row.
	 * @param data
	 * @param row
	 * @return Lowest number in selected row of 2D array
	 */
	public static double getLowestInRow(double[][] data, int row) {
	    double lowest = data[row][0];
	    for (int col = 0; col < data[row].length; col++) {
	        if (data[row][col] < lowest) {
	            lowest = data[row][col];
	        }
	    }
	    return lowest;
	}
	
	/**
	 *   Returns the index of the smallest element of the selected row in the two dimensional array index 0 refers to the first row.
	 * @param data
	 * @param row
	 * @return Position in array row where lowest number is located
	 */
	public static int getLowestInRowIndex(double[][] data, int row) {
	    double lowest = data[row][0];
	    int lowestIndex = 0;
	    for (int col = 0; col < data[row].length; col++) {
	        if (data[row][col] < lowest) {
	            lowest = data[row][col];
	            lowestIndex = col;
	        }
	    }
	    return lowestIndex;
	}
	
	/**
	 * Returns the total of the selected row in the two dimensional array index 0 refers to the first row.
	 * @param data
	 * @param row
	 * @return Total of selected row of 2D array
	 */
	public static double getRowTotal(double[][] data, int row) {
	    double total = 0;
	    for (int col = 0; col < data[row].length; col++) {
	        total += data[row][col];
	    }
	    return total;
	}
	
	/**
	 * Returns the total of all the elements of the two dimensional array
	 * @param data
	 * @return Total of all calues of 2D array
	 */
	public static double getTotal(double[][] data) {
	    double total = 0;
	    for (int row = 0; row < data.length; row++) {
	        for (int col = 0; col < data[col].length; col++) {
	            total += data[row][col];
	        }
	    }
	    return total;
	}
	
	/**
	 * Reads from a file and returns a ragged array of doubles 
	 * @param file
	 * @return
	 * @throws FileNotFoundException 
	 */
	public static double[][] readFile(File file) throws FileNotFoundException{
		ArrayList<ArrayList<Double>> raggedArray = new ArrayList<>();
		try {
			Scanner inputFile = new Scanner(file);
		
			while(inputFile.hasNextLine()) {
				String line = inputFile.nextLine();
				String[] values = line.split(" ");
				ArrayList<Double> next = new ArrayList<>();
				for(String number : values) {
					next.add(Double.parseDouble(number));
				}
				raggedArray.add(next);
			}
			inputFile.close();
		} catch (FileNotFoundException e) {
	        System.err.println("File not found: " + file);
	        e.printStackTrace();
	    }
		
		double[][] array = new double[raggedArray.size()][];
	    for (int i = 0; i < raggedArray.size(); i++) {
	        ArrayList<Double> row = raggedArray.get(i);
	        array[i] = new double[row.size()];
	        for (int j = 0; j < row.size(); j++) {
	            array[i][j] = row.get(j);
	        }
	    }
	    return array;
	}
	
	
	/**
	 * Writes the ragged array of doubles into the file.
	 * @param data
	 * @param file
	 * @throws IOException 
	 */
	public static void writeToFile(double[][] data, File file) throws IOException {
		FileWriter fileWriter = new FileWriter(file);
	    for (int i = 0; i < data.length; i++) {
	        for (int j = 0; j < data[i].length; j++) {
	            fileWriter.write(String.valueOf(data[i][j]));
	            if (j < data[i].length - 1) {
	                fileWriter.write(" ");
	            }
	        }
	        if (i < data.length - 1) {
	            fileWriter.write("\n");
	        }
	    }
	    fileWriter.close();
	}
	
	
	
}