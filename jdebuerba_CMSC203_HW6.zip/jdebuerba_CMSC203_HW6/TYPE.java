package package1;

public enum TYPE {
	COFFEE, SMOOTHIE, ALCOHOL;
}