package package1;

class Coffee extends Beverage{						//Subclass of Superclass Beverage
	private boolean extraShot;						//Boolean holds true if beverage has a extra shot
	private boolean extraSyrup;						//Boolean holds true if beverage has extra syrup
	private final double COST_OF_SHOT = .5; 		//Double holds the cost of a shot
	private final double COST_OF_SYRUP = .5;		//Double hold the cost of syrup

	/**
	 * Constructor for Coffee subclass with 4 paramters
	 * @param name name for beverage
	 * @param size size of beverage
	 * @param shot has extra shot
	 * @param syrup has extra syrup
	 */
	public Coffee(String name, SIZE size, boolean shot, boolean syrup) {
		super(name, TYPE.COFFEE, size);
		extraShot = shot;
		extraSyrup = syrup;
	}

	/**
	 * Getter returns true if has extra shot
	 * @return extraShot extraShot returns true if has extra shot, false if not
	 */
	public boolean getExtraShot() {
		return extraShot;
	}
	
	/**
	 * Getter returns true if has extra syrup
	 * @return extraSyrup extraSyrup returns true if has extra syrup, false if not
	 */
	public boolean getExtraSyrup() {
		return extraSyrup;
	}
	
	/**
	 * Getter gets the cost of shot
	 * @return COST_OF_SHOT cost of shot
	 */
	public double getCostOfShot() {
		return COST_OF_SHOT;
	}
	
	/**
	 * Getter gets the cost of syrup
	 * @return COST_OF_SYRUP cost of syrup
	 */
	public double getCostOfSyrup() {
		return COST_OF_SYRUP;
	}

	/**
	 * Setter sets Coffee object with extra shot
	 * @param extraShot
	 */
	public void setExtraShot(boolean shot) {
		extraShot = shot;
	}
	
	/**
	 * Setter sets Coffee object with extra syrup
	 * @param extraSyrup
	 */
	public void setExtraSyrup(boolean syrup) {
		extraSyrup = syrup;
	}

	/**
	 * Overriden toString displays name, size, whether has extra shot, whether has extra syrup, and price
	 */
	public String toString() {
		String info = getName() + ", " + getSize();
		if (extraShot) {
			info += " Coffee with extra shot ";
		}
		
		if (extraSyrup) {
			info += ", with extra syrup";
		}
		
		info += ", $" + calcPrice();
		return info;
	}
	
	/**
	 * Method calculates price of Coffee per order
	 */
	public double calcPrice() {
		double totalPrice = super.getPriceOfBase();
		if (super.getSize() == SIZE.MEDIUM) {
			totalPrice += super.getPriceOfSize();
		}
		
		if (super.getSize() == SIZE.LARGE) {
			totalPrice += 2 * super.getPriceOfSize();
		}

		if (extraShot) {
			totalPrice += COST_OF_SHOT;
		}
		
		if (extraSyrup) {
			totalPrice += COST_OF_SYRUP;
		}
		
		return totalPrice;
	}
	
	public boolean equals(Coffee coffee) {
		if (super.equals(coffee) && extraShot == (coffee.getExtraShot()) && extraSyrup == (coffee.getExtraSyrup())) {
			return true;
		}
		
		else {
			return false;
		}
	}
}

