package package1;

class Customer {
	private String name; 		//Name of Customer
	private int age; 			//Age of Customer

	/**
	 * Constructor that passes the customers name and age as arguments
	 * @param name name of customer
	 * @param age age of customer
	 */
	public Customer(String name, int age) {
		this.name = name;
		this.age = age;
	}
	
	/**
	 * Copy constructor
	 * @param customer
	 */
	public Customer(Customer customer) {
		this.name = customer.getName();
		this.age = customer.getAge();
	}

	/**
	 * Getter retrieves name of customer
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * Getter retrieves age of customer
	 * @return
	 */
	public int getAge() {
		return age;
	}

	/**
	 * Setter sets the name of a customer
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * Setter sets the age of a customer
	 * @param age
	 */
	public void setAge(int age) {
		this.age = age;
	}

	/**
	 * String representation for Customer including the name and age
	 */
	public String toString() {
		String info = name + ", is " + age +" years old";
		return info;
	}
}


