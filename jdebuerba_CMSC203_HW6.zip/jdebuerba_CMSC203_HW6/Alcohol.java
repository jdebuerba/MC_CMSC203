package package1;

class Alcohol extends Beverage{					//Subclass of Beverage class
	private boolean isWeekend; 					//tests if it is a weekend
	private final double WEEKEND_FEE = .6; 		//fee during the weekend

	/**
	 * Constructor for Alcohol with 3 parameters
	 * @param name 
	 * @param size
	 * @param isWeekend
	 */
	public Alcohol(String name, SIZE size, boolean isWeekend) {
		super(name, TYPE.ALCOHOL, size);
		this.isWeekend = isWeekend;
	}
	
	/**
	 * Getter for weekend value
	 * @return isWeekend if it is a weekend, True, if it is not a weekend, False
	 */
	public boolean getIsWeekend() {
		return isWeekend;
	}
	
	/**
	 * Getter for weekend fee
	 * @return weekend fee extra fee for weekends
	 */
	public double getWeekendFee() {
		return WEEKEND_FEE;
	}

	/**
	 * Setter to set if weekend
	 * @param isWeekend sets value if it is or is not a weekend
	 */
	public void setIsWeekend(boolean isWeekend) {
		this.isWeekend = isWeekend;
	}
	
	/**
	 * Overwritten toString
	 */
	public String toString() {
		String info = getName() + ", " + getSize();
		if (isWeekend) {
			info += ", Weekend";
		}
		info += ", $" +calcPrice();
		return info;
	}
	
	/**
	 * Method equals for comparing two objects of a class
	 * @param alcohol compares a object with another too see if they are equal
	 * @return equal returns true if equal and returns false if not equal
	 */
	public boolean equals(Alcohol alcohol) {
		if (super.equals(alcohol) && isWeekend == alcohol.getIsWeekend()) {
			return true;
		}
		else {
			return false;
		}
	}
	
	/**
	 * Calculates the total price of alcohol ordered
	 */
	public double calcPrice() {
		double totalprice = super.getPriceOfBase();
		if (super.getSize() == SIZE.MEDIUM) {
			totalprice += super.getPriceOfSize();			//Calls price of regular size from Superclass
		}
		if (super.getSize() == SIZE.LARGE) {
			totalprice += 2 * super.getPriceOfSize();		//Multiplies regular size price by 2 for large alcohol
		}
		if (isWeekend) {
			totalprice += WEEKEND_FEE;						//Adds a fee if it is the weekend
		}

		return totalprice;
	}
}