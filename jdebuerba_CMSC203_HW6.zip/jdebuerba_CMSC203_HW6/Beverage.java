package package1;

public abstract class Beverage {
	private String name;					//Name for beverage
	private TYPE type;						//Enum variable for type of beverage
	private SIZE size;						//Enum varibale for size of beverage
	private final double BASE = 2.0;		//Double holds the base price of a beverage
	private final double SIZE = 1.0;		//Double holds the size price of a beverage

	/**
	 * Constructor builds a Beverage object with arguments
	 * @param name name of beverage
	 * @param type type of beverage
	 * @param size size of beverage
	 */
	public Beverage(String name, TYPE type, SIZE size) {
		this.name = name;
		this.type = type;
		this.size = size;
		}

	/**
	 * Super Method for calculating price of beverages 
	 * @return calcPrice from subclasses
	 */
	public abstract double calcPrice();
	
	/**
	 * Getter for name of beverage
	 * @return name name for beverage
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Getter for type of beverage
	 * @return type type of beverage refers to Enum
	 */
	public TYPE getType() {
		return type;
	}
	
	/**
	 * Getter for size of beverage
	 * @return size size of beverage refers to Enum
	 */
	public SIZE getSize() {
		return size;
	}
	
	/**
	 * Getter for base price of beverages
	 * @return BASE
	 */
	public double getPriceOfBase() {
		return BASE;
	}
	
	/**
	 * Getter for price of beverage per size
	 * @return SIZE
	 */
	public double getPriceOfSize() {
		return SIZE;
	}

	/**
	 * Setter sets name of beverage
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * Setter sets type of beverage
	 * @param type
	 */
	public void setType(TYPE type) {
		this.type = type;
	}
	
	/**
	 * Setter sets size of beverage
	 * @param size
	 */
	public void setSize(SIZE size) {
		this.size = size;
	}
	
	/**
	 * Overriden toString converts name and size into a String
	 */
	public String toString() {
		String nameAndSize = name + ", " + size;
		return nameAndSize;
	}
	
	/**
	 * Super method for class Beverage 
	 * @param beverage compares a beverage object with another, True, if equal, False, if not equal
	 * @return true if equal or false if not
	 */
	public boolean equals(Beverage beverage) {
		if (name.equals(beverage.getName()) && type.equals(beverage.getType()) && size.equals(beverage.getSize())) {
			return true;
		}
		else {
			return false;
		}
	}
}

