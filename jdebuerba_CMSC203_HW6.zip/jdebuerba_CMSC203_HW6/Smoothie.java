package package1;

class Smoothie extends Beverage{ 					//Subclass of Beverage class		
	private int fruit;								//Int holds amount of fruit
	private boolean hasProtein;						//Boolean is true if smoothie has protein powder	
	private final double COST_OF_FRUIT = .5;		//Final double with price of fruit
	private final double COST_OF_PROTEIN = 1.5;		//Final double with price of protein

	/**
	 * Constructor for smoothie class has 4 arguments
	 * @param name name for beverage
	 * @param size size of beverage
	 * @param fruit amount of fruit
	 * @param protein if has protein or not
	 */
	public Smoothie(String name, SIZE size, int fruit, boolean protein) {
		super(name, TYPE.SMOOTHIE, size);
		this.fruit = fruit;
		hasProtein = protein;
	}

	/**
	 * Getter gets the amount of fruit
	 * @return fruit amount of fruit in smoothie
	 */
	public int getFruit() {
		return fruit;
	}
	
	/**
	 * Getter if has protein
	 * @return hasProtein returns true if smoothie has protein powder, false if does not have protein powder
	 */
	public boolean gethasProtien() {
		return hasProtein;
	}
	
	/**
	 * Getter for cost per fruit
	 * @return COST_OF_FRUIT
	 */
	public double getFruitCost() {
		return COST_OF_FRUIT;
	}
	
	/**
	 * Getter for cost of protein
	 * @return COST_OF_PROTEIN
	 */
	public double getProteinCost() {
		return COST_OF_PROTEIN;
	}

	/**
	 * Setter sets number of fruit in smoothie
	 * @param fruit
	 */
	public void setNumOfFruits(int fruit) {
		this.fruit = fruit;
	}
	
	/**
	 * Setter sets true to smoothie object if has protein powder
	 * @param protein
	 */
	public void setProteinPowder(boolean protein) {
		hasProtein = protein;
	}
	
	/**
	 * Overriden toString taht displays name, size, fruit, whether smootie has protein powder, and price of smoothie
	 */
	public String toString() {
		String info = getName() +", " + getSize() + " Smoothie with " + fruit + " pieces of fruit";
		if (hasProtein) {
			info += ", with protein powder";
		}

		info += ", $" +calcPrice();
		return info;
	}
	
	/**
	 * Method compares two smoothie objects to see if they are equal
	 * @param smoothie compares this object with another
	 * @return true if smoothie is equal
	 */
	public boolean equals(Smoothie smoothie) {
		if (super.equals(smoothie) && fruit == (smoothie.getFruit()) && hasProtein == smoothie.gethasProtien()) {
			return true;
		}
		else {
			return false;
		}
	}
	
	/**
	 * Method calculates the price of smoothie
	 */
	public double calcPrice() {
		double totalprice = super.getPriceOfBase();
		if (super.getSize() == SIZE.MEDIUM) {
			totalprice += super.getPriceOfSize();
		}
		
		if (super.getSize() == SIZE.LARGE) {
			totalprice += 2 * super.getPriceOfSize();
		}
		
		if (hasProtein) {
			totalprice += COST_OF_PROTEIN;
		}
		
		totalprice += fruit * COST_OF_FRUIT;
		return totalprice;
	}
}