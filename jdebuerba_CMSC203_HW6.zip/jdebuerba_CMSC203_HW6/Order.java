package package1;

import java.util.ArrayList;
import java.util.Random;


class Order implements OrderInterface, Comparable<Order> {		//Order class implements two interfaces
	private DAY orderDay;										//Enum variable holds the day of the order
	private int orderNumber;									//Int holds the order number
	private int orderTime;										//Int holds the time of order
	private Customer customer;									//Customer reference for each new customer
	private ArrayList<Beverage> beverages;						//Makes an arraylist of different beverages


	public Order(int orderTime, DAY orderDay, Customer customer) {
		orderNumber = randomNumber();
		this.orderTime = orderTime;
		this.orderDay = orderDay;
		this.customer = customer;
		beverages = new ArrayList<>();
	}

	public int getTotalItems() {
		return beverages.size();
	}
	
	/**
	 * returns the beverage listed in the itemNo of the order
	 * @return the beverage listed in the itemNo of the order or null if there
	 *         is no item in the order
	 * 
	 */
	public Beverage getBeverage(int itemNo) {
		return beverages.get(itemNo);
	}

	/**
	 * adds coffee order to this order
	 * @param bevName beverage name
	 * @param size beverage size of type SIZE
	 * @param extraShot true if the coffee beverage has extra shot , false otherwise
	 * @param extraSyrup true if the coffee beverage has extra syrup , false otherwise
	 */
	public void addNewBeverage(String bevName, SIZE size, boolean extraShot, boolean extraSyrup) {
		Coffee coffee = new Coffee(bevName, size, extraShot, extraSyrup);
		beverages.add(coffee);
	}
	
	/**
	 * adds alcohol order to this order
	 * @param bevName beverage name
	 * @param size beverage size
	 */ 
	public void addNewBeverage(String name, SIZE size) {
		boolean isWeekend = false;
		if (orderDay == DAY.SATURDAY || orderDay == DAY.SUNDAY) {
			isWeekend = true;
		}
		Alcohol alcohol = new Alcohol(name, size, isWeekend);
		beverages.add(alcohol);
	}
	
	/**
	 * Adds the Smoothie beverage to this order
	 * @param bevName beverage name
	 * @param size beverage size
	 * @param numOfFruits number of fruits added 
	 * @param addPRotien true if protein is added, false otherwise
	 */
	public void addNewBeverage(String bevName, SIZE size, int fruit, boolean proteinPowder) {
		Smoothie smoothie = new Smoothie(bevName, size, fruit, proteinPowder);
		beverages.add(smoothie);
	}

	/**
	 * Getter returns order number as a int
	 * @return orderNumber
	 */
	public int getOrderNo() {
		return orderNumber;
	}
	
	/**
	 * Getter returns the time of order
	 * @return orderTime
	 */
	public int getOrderTime() {
		return orderTime;
	}
	
	/**
	 * Returns orderDay from enum DAY
	 * @return orderDay
	 */
	public DAY getOrderDay() {
		return orderDay;
	}
	
	/**
	 * Getter returns a new customer
	 * @return Customer
	 */
	public Customer getCustomer() {
		return new Customer(customer);
	}
	
	/**
	 * Getter creates an arraylist of various beverages
	 * @return beverages
	 */
	public ArrayList<Beverage> getBeverages() {
		return beverages;
	}

	/**
	 * Setter sets a order number
	 * @param orderNumber
	 */
	public void setOrderNum(int orderNumber) {
		this.orderNumber = orderNumber;
	}

	/**
	 * Setter sets a order time
	 * @param orderTime
	 */
	public void setOrderTime(int orderTime) {
		this.orderTime = orderTime;
	}

	/**
	 * Setter sets day of order from enum
	 * @param orderDay
	 */
	public void setOrderDay(DAY orderDay) {
		this.orderDay = orderDay;
	}

	public void setCustomer(Customer customer) {
	this.customer = customer;
	}
	
	public String toString() {
		String info = "Order Number: " + orderNumber + ", " + orderDay.toString() + ", " + orderTime + "\n" + customer.toString();
		for (Beverage beverage : beverages) {
			info += "\n" + beverage.toString();
		}
		
		info += "\n" + "Order Total: " + calcOrderTotal();
		return info;
	}
	
	/**
	 * 
	 * @param day the day of the week
	 * @return true if the day is a weekend day (Saturday or Sunday)
	 */
	public boolean isWeekend() {
		if (orderDay == DAY.SATURDAY || orderDay == DAY.SUNDAY) {
			return true;
		}
		return false;
	}
	
	/**
	 * Calculates and returns the total amount for this order
	 * @return total amount for this order
	 */
	public double calcOrderTotal() {
		double ordertotal = 0;
		for (Beverage beverage : beverages) {
			ordertotal += beverage.calcPrice();
		}

		return ordertotal;
	}
	
	/**
	 * returns the number of beverages of same type in an order
	 * @param type the type of the beverage
	 * @return number of beverages of type type in this order
	 */
	public int findNumOfBeveType(TYPE type) {
		int count = 0;
		for (Beverage beverage : beverages) {
			if (beverage.getType() == type) {
				count++;
			}
		}

		return count;
	}

	/**
	 * Method creates a random integer between 10,000 and 90,000
	 * @return randomNumber a random number
	 */
	public int randomNumber() {
		Random random = new Random();
		int randomNumber = random.nextInt(90000-10000)+10000;
		return randomNumber;
	}
	
	/**
	 * Compares order numbers returns 0 if order numbers are the same
	 */
	public int compareTo(Order order) {
		if (orderNumber == order.getOrderNo()) {
			return 0;
		}
		else if (orderNumber > order.getOrderNo()) {
			return 1;
		}
		else {
			return -1;
		}
	}
}