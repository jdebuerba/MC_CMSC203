package package1;

import java.util.ArrayList;

class BevShop implements BevShopInterface{		//Class implements an Interface for BevShop
	private int alcoholPerOrder;		 		//Counts the alcohol per order
	private int currentOrder; 					//Current index in arraylist
	private ArrayList<Order> orders; 			//List to keep track of orders

	public BevShop() { 			//Default constructor 
		orders = new ArrayList<>();
	}

	/**
	 * Returns the string representation of all the orders and the total monthly sale.  
	 */
	public String toString() {
		String info = "Monthly Orders: ";
		for (Order order : orders) {
			info += order.toString();
		}
		info += "\n Total Sales: " + totalMonthlySale();
		return info;
	}

	/**
	 * Checks if the time is valid (between 8 and 23 )
	 * @param time time represents the time 
	 * @return true if times is within the range of 8 to 23 , false otherwise
	 */
	public boolean validTime(int time) {
		if (time >= MIN_TIME && time <= MAX_TIME) {
			return true;
		}	
		return false;
	}
	
	/**
	 * checks if the number of alcohol beverages for the current order has reached the maximum
	 * @return true if number of alcohol drinks for the current order has reached the maximum , false otherwise
	 */
	public boolean eligibleForMore() {
		if (alcoholPerOrder < MAX_ORDER_FOR_ALCOHOL) {
			return true;
		}
		return false;
	}
	
	/**
	 * check the valid age for the alcohol drink
	 * @param age the age  
	 * @return returns true if age is more than minimum eligible age , false otherwise  
	 */
	public boolean validAge(int age) {
		if (age >= MIN_AGE_FOR_ALCOHOL) {
			return true;
		}
		return false;
	}

	/**
	  * Creates a new order ,  NO BEVERAGE is added to the order yet 
	  * @param time time of the order  
	  * @param day day of the order of type DAY
	  * @param customerName customer name 
	  * @param customerAge customer age
	  */
	public void startNewOrder(int time, DAY day, String customerName, int customerAge) {
		Customer customer = new Customer(customerName, customerAge);
		Order order = new Order(time, day, customer);
		orders.add(order);
		currentOrder = orders.indexOf(order);
		alcoholPerOrder = 0;
	}
	
	/**
	 * process the Coffee order for the current order by adding it to the current order
	 * @param bevName beverage name
	 * @param size beverage size
	 * @param extraShot true if the coffee beverage has extra shot , false otherwise
	 * @param extraSyrup true if the coffee beverage has extra syrup , false otherwise
	 */
	public void processCoffeeOrder(String bevName, SIZE size, boolean extraShot, boolean extraSyrup) {
		orders.get(currentOrder).addNewBeverage(bevName, size, extraShot, extraSyrup);
	}

	/**
	 * process the Alcohol order for the current order by adding it to the current order
	 * @param bevName beverage name
	 * @param size beverage size
	 */
	public void processAlcoholOrder(String bevName, SIZE size) {
		orders.get(currentOrder).addNewBeverage(bevName, size);
		alcoholPerOrder++;
	}
	
	/**
	 * process the Smoothie order for the current order  by adding it to the current order
	 * @param bevName beverage name
	 * @param size beverage size
	 * @param numOfFruits number of fruits to be added 
	 * @param addProtien true if protein is added , false otherwise
	 */
	public void processSmoothieOrder(String bevName, SIZE size, int numOfFruits, boolean addProtein) {
		orders.get(currentOrder).addNewBeverage(bevName, size, numOfFruits, addProtein);
	}

	/**
	 * locate an order based on  the order number
	 * @param orderNo the order number
	 * @return the index of the order in the list of Orders  if found or -1 if not found
	 */
	public int findOrder(int orderNo) {
		for (int i = 0; i < orders.size(); i++) {
			if (orders.get(i).getOrderNo() == orderNo) {
				return i;
			}
		}

		return -1;
	}
	
	/**
	 * locates an order in the list of orders and returns the total value on the order.
	 * @param orderNo the order number
	 * @returns the calculated price on this order.
	 */
	public double totalOrderPrice(int orderNo) {
		double totalOrders = 0;
		for (Order order : orders) {
			if (order.getOrderNo() == orderNo) {
				for (Beverage beverage : order.getBeverages()) {
					totalOrders += beverage.calcPrice();
				}
			}
		}

		return totalOrders;
	}
	
	/**
	 *  Calculates the total sale of all the orders for this beverage shop
	 *  @return the total sale of all the orders 
	 */
	public double totalMonthlySale() {
		double totalOrders = 0;
		for (Order order : orders) {
			for (Beverage beverage : order.getBeverages()) {
				totalOrders += beverage.calcPrice();
			}
		}

		return totalOrders;
	}
	
	/**
	 * sorts the orders within this bevShop using the Selection
	 * sort algorithm
	 */
	public void sortOrders() {
		for (int i = 0; i < orders.size() - 1; i++) {
			int lowestNumberIndex = i;
			for (int j = i+1; j < orders.size(); j++) {
				if (orders.get(j).getOrderNo() < orders.get(lowestNumberIndex).getOrderNo()) {
					lowestNumberIndex = j;
				}
			}
			Order temporary = orders.get(lowestNumberIndex);
			orders.set(lowestNumberIndex, orders.get(i));
			orders.set(i, temporary);
		}
	}
	
	/**
	 * returns Order in the list of orders at the index
	 * Notes: this method returns the shallow copy of the order
	 * @return Order in the list of orders at the index 
	 */
	public Order getOrderAtIndex(int index) {
		return orders.get(index);
	}
	
	/**
	 * Getter returns maximum number of alcohol per order as an integer
	 * @return maximum alcohol per order
	 */
	public int getMaxOrderForAlcohol() {
		return MAX_ORDER_FOR_ALCOHOL;
	}
	
	/**
	 * Getter returns the minimum drinking age as an integer
	 * @return minimum drinking age
	 */
	public int getMinAgeForAlcohol() {
		return MIN_AGE_FOR_ALCOHOL;
	}
	
	/**
	 * Tests to see if beverage has exceeded the maximum fruit allowed
	 * @param num of fruit
	 * @return true or false if fruit exceeds amximum number
	 */
	public boolean isMaxFruit(int num) {
		if (num > MAX_FRUIT) {
			return true;
		}
		return false;
	}

	/**
	 * Retrieves the current order index in the Arraylist
	 * @return current order 
	 */
	public Order getCurrentOrder() {
		return orders.get(currentOrder);
	}
	
	/**
	 * Getters returns the amount of alcohol per order
	 * @return alcohol per order
	 */
	public int getNumOfAlcoholDrink() {
		return alcoholPerOrder;
	}
}