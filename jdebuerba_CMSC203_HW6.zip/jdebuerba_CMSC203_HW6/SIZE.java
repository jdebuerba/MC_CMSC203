package package1;

public enum SIZE {
	SMALL, MEDIUM, LARGE;
}
