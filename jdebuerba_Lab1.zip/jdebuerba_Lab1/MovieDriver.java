
import java.util.Scanner;
public class MovieDriver {

public static void main(String[] args) {

	Scanner scan = new Scanner(System.in); //Object of type Scanner 
	Movie movie = new Movie(); //Object for movie class
	String movieName = "";
	String movieRating = "";
	int ticketsSold = 0;
	char again = 'y';
	
	while(again == 'y' || again == 'Y'){ 

		System.out.println("Enter the name of movie "); //Prompt to enter movie name
		movieName = scan.nextLine(); //Read user input
		movie.setTitle(movieName); //Set input in movie object

		System.out.println("Enter the rating of movie ");
		movieRating = scan.nextLine(); //Read user input
		movie.setRating(movieRating); //Set input in movie object

		System.out.println("Enter number of tickets sold for this movie");
		ticketsSold = scan.nextInt(); //Read user input
		movie.setSoldTickets(ticketsSold); //Set input in movie object
		scan.nextLine(); //Fix buffer
	
		String movieOutput = movie.toString(); //Call method and assign it to a string
		System.out.println(movieOutput);

		System.out.println("Do you want to enter another movie?(y/n)"); //Prompt user to replay program
		again = scan.nextLine().charAt(0);
		System.out.println();
		
		}
	
	System.out.print("Goodbye");

	scan.close(); //Close object scanner

	}
}
