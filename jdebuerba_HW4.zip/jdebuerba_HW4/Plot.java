package application;

public class Plot {
	
	//Field variables declared
	private int x;
	private int y;
	private int width;
	private int depth;
	
	//Class constructor no arg
	public Plot(){
		this.x = 0;
		this.y = 0;
		this.width = 1;
		this.depth = 1;
	}
	
	/**
	Class constructor with object parameters
	* @param p Plot object
	*/
	public Plot(Plot p) {
		this.x = p.x;
		this.y = p.x;
		this.width = p.width;
		this.depth = p.depth;
	}
	
	/**
	Class constructor with parameters
	* @param x x position
   * @param y y position
   * @param width width of plot
   * @param depth depth of plot
	*/
	public Plot(int x, int y, int width, int depth) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.depth = depth;
	}
	
	/**
	Setter for x position
	* @param x x position
	*/
	public void setX(int x) {
		this.x = x;
	}
	
	/**
	Getter for x position
	* @return x x position
	*/
	public int getX() {
		return x;
	}
	
	/**
	Setter for y position
	* @param y y position
	*/
	public void setY(int y) {
		this.y = y;
	}
	
	/**
	Getter for y position
	* @return y y position
	*/
	public int getY() {
		return y;
	}
	
	/**
	Setter for width of plot
	* @param width width of plot
	*/
	public void setWidth(int width) {
		this.width = width;
	}
	
	/**
	Getter for width of plot
	* @return width width of plot
	*/
	public int getWidth() {
		return width;
	}
	
	/**
	Setter for depth of plot
	* @param depth depth of plot
	*/
	public void setDepth(int depth) {
		this.depth = depth;
	}
	
	/**
	Getter for depth of plot
	* @return depth depth of plot
	*/
	public int getDepth() {
		return depth;
	}
	
	/**
	   * toString method prints out plot object
	   * @return String
	   */
	public String toString() {
		return "Upper left: " + "(" + getX() + "," + getY() + "); " + "Width: " + getWidth() + " Depth: " + getDepth() + " ";
	}
	
	/**
	   * Method determines if plot overlaps the parameter
	   * @return boolean
	   */
	public boolean overlaps (Plot plot) {
		boolean overlaping = false;
		if ((getX() + getWidth()) > plot.getX() || (getY() + getWidth()) > plot.getY()) {
			overlaping = true;
		}
			
		if ((plot.getY() + plot.getWidth()) > getY() || (plot.getX() + plot.getWidth()) > getX()) {
			overlaping = true;
		}

		if ((getX() < plot.getY() || (getX() + getWidth()) < (plot.getY() + plot.getWidth()))) {
			overlaping = true;
		}
				
		if (((plot.getX() + plot.getWidth()) < (getY() + getWidth())) || (plot.getX() < getX())){
			overlaping = true;
		}
		
		return overlaping;
	}
	
	/**
	   * Method determines if plot encompasses parameter
	   * @return boolean
	   */
	public boolean encompasses(Plot plot) {
		boolean encompassing = false;
		
		if ((plot.getX() + plot.getWidth()) < (getX() + getWidth())){
			encompassing = true;
		}
		
		if ((plot.getX() + plot.getDepth()) < (getX() + getDepth())){
			encompassing = true;
		}
		
		if ((plot.getX() + plot.getDepth() + plot.getWidth()) < (getX() + getDepth() + getWidth())){
			encompassing = true;
		}
		
		if (plot.getX() < getX()){
			encompassing = true;
		}
		
		if ((plot.getX() + plot.getWidth()) > (getWidth() + getX())){
			encompassing = true;
		}
		
		if (plot.getX() > getX()){
			encompassing = true;	
		}
		
		if ((plot.getX() + plot.getDepth() + plot.getWidth() + plot.getDepth()) < (getX() + getDepth() + getWidth()+ getDepth())){
			encompassing = true;
		}
		
		if ((plot.getX() + plot.getWidth()) > (getWidth() + getX())){
			encompassing = true;
		}
		
		if(plot.getY() > getX()) {
			encompassing = true;
		}
		
		if(plot.getY() > (getY() + getWidth())) {
			encompassing = true;
		}
		
		
		return encompassing;
	
	}
}
	
	
	

