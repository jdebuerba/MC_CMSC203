package application;

public class ManagementCompany {
	
	//Field variables declared
	private int MAX_PROPERTY = 5;
	private int MGMT_WIDTH = 10;
	private int MGMT_DEPTH = 10;
	private double mgmFeePer;
	private String name;
	private String taxID;
	private Property[] properties;
	private Plot plot;
	
	//Class constructor no arg
	ManagementCompany(){
		this.name = null;
		this.taxID = null;
		this.plot = new Plot(0, 0, MGMT_WIDTH, MGMT_DEPTH);
		this.properties = new Property[MAX_PROPERTY];
	}
	
	/**
	Class constructor with parameters
	* @param name name of the company
   * @param taxID taxID of the company
   * @param mgmFeePer management fee
	*/
	public ManagementCompany(String name, String taxID, double mgmFeePer){
		this.name = name;
		this.taxID = taxID;
		this.mgmFeePer = mgmFeePer;
		this.plot = new Plot(0, 0, MGMT_WIDTH, MGMT_DEPTH);
		this.properties = new Property[MAX_PROPERTY];
	}
	
	
	/**
	Class constructor with more parameters
	* @param name name of the company
   * @param taxID taxID of the company
   * @param mgmFeePer management fee
   * @param x x position
   * @param y y position
   * @param width width of property
   * @param depth depth of property
	*/
	public ManagementCompany(String name, String taxID, double mgmFeePer, int x, int y, int width, int depth){
		this.name = name;
		this.taxID = taxID;
		this.mgmFeePer = mgmFeePer;
		this.plot = new Plot(x, y, width, depth);
		this.properties = new Property[MAX_PROPERTY];
	}
	
	/**
	Class constructor that makes objects with another object
	* @param name name of the company
   * @param taxID taxID of the company
   * @param mgmFeePer management fee
   * @param plot plot object of class Plot
   * @param properties properties 
	*/
	public ManagementCompany(ManagementCompany otherCompany){
		this.name = otherCompany.name;
		this.taxID = otherCompany.taxID;
		this.mgmFeePer = otherCompany.mgmFeePer;
		this.plot = otherCompany.plot;
		this.properties = otherCompany.properties;
	}
	
	/**
	   * Getter that returns the size of properties array
	   * @return MAX_PROPERTY size of array.
	   */
	public int getMAX_PROPERTY(){
		return MAX_PROPERTY;
	}
	
	/**
	   * Method that adds a property to the properties array
	   * @param property
	   * @return int
	   */
	public int addProperty(Property property) {
		int temp = 0;
		for (int i = 0; i < MAX_PROPERTY; i++) {
			properties[i] = property;
			if (properties.length == MAX_PROPERTY) {
				temp = -1;
			} 
			if (property.equals(null)) {
				temp = -2;
			} else if (properties[0].getPlot().encompasses(properties[i].getPlot())) {
				temp = -3;
			} 
			if (properties[i].getPlot().overlaps(properties[0].getPlot())) {
				temp = -4;
			}
		}
		return temp;
	}
	
	/**
	   * Method that adds a property with four parameters 
	   * @param name name of property
	   * @param city city of property
	   * @param rent rent of property
	   * @param owner owner of property
	   * @return int
	   */
	public int addProperty(String name,String city,double rent,String owner) {
		Property property1 = new Property(name, city, rent, owner);
		int temp = 0;
		for (int i = 0; i < properties.length; i++) {
			if (properties.length == MAX_PROPERTY) {
				temp = -1;
			}
			if (property1 == null) {
				temp = -2;
			}
			if (properties[0].getPlot().encompasses(properties[i].getPlot())) {
				temp = -3;
			}
			if (properties[i].getPlot().overlaps(properties[0].getPlot())) {
				temp = -4;
			}
		}
		return temp;
	}
	
	/**
	   * Method that adds a property that has all the parameters for the property and plot
	   * @param name name of property
	   * @param city city of property
	   * @param rent rent of property
	   * @param owner owner of property
	   * @param x x position of property
	   * @param y y postion of property
	   * @param width width of property
	   * @param depth depth of property
	   * @return int
	   */
	public int addProperty(String name,String city,double rent,String owner,int x,int y,int width,int depth) {
		Property property = new Property(name, city, rent, owner, x, y, width, depth);
		int temp = 0;
		for (int i = 0; i < properties.length; i++) {
			 if (property.equals(null)) {
				temp = -2;
			 }
			 if (properties[0].getPlot().encompasses(properties[i].getPlot())) {
				temp = -3;
			 }
			 if (properties[i].getPlot().overlaps(properties[0].getPlot())) {
				temp = -4;
			 }
			 if (properties.length == MAX_PROPERTY) {
				temp = -1;
			 }
		}
		return temp;
	}
	
	/**
	   * Method that adds up all the amounts of rent.
	   * @return double
	   */
	public double totalRent() {
		int sum = 0;
		for (int i = 0; i < properties.length; i++) {
			sum += properties[i].getRentAmount();
		}
		return sum;
	}
	
	/**
	   * Method finds property with highest rent
	   * @return double
	   */
	public double maxRentProp() {
		double maximumRent = 0; 
		for (int i = 0; i < properties.length; i++) {
			if (properties[i].getRentAmount() > properties[0].getRentAmount()) {
				maximumRent = properties[i].getRentAmount();
			}
		}
		return maximumRent;
	}
	
	/**
	   * Method finds property index with highest rent
	   * @return double
	   */
	private int maxRentPropertyIndex() {
		int maximumIndex = 0; 
		for (int i = 0; i < properties.length; i++) {
			if (properties[i].getRentAmount() > properties[0].getRentAmount()) {
				maximumIndex = i;
			}
		}
		return maximumIndex;
	}
	
	/**
	   * Method finds property index in properties array
	   * @return double
	   */
	private String displayPropertyAtIndex(int i) {
		String index = properties[i].toString();
		return index;
	}
	
	/**
	   * toString method returns a String of an object
	   * @return String
	   */
	public String toString() {
		String printProperty;
		printProperty = "List of the properties for Alliance, taxID: " + taxID + "\n" + "______________________________________________________" + "\n";
		for(int i=0;i < properties.length;i++) {
			printProperty += " Property Name: " + properties[i].getPropertyName() + "\n" + " Located in: " + properties[i].getCity() + "\n" +
			          " Belonging to: " + properties[i].getOwner() + "\n" + " Rent Amount: " + properties[i].getRentAmount() + "\n";
			}
			printProperty += "______________________________________________________" + "\n" + "total management Fee: " + mgmFeePer;
		return printProperty;
	}
	
	public Plot getPlot() {
		return plot;
	}

	public String getName() {
		return name;
	}

}


	
