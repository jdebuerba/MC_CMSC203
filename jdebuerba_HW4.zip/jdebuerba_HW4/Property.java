package application;

public class Property {
	
	//Field variables declared
	private String city;
	private String owner;
	private String propertyName;
	private double rentAmount;
	private Plot plot;
	
	//Class constructor no arg
	public Property(){
		city = null;
		owner = null;
		propertyName = null;
		rentAmount = 0;
		this.plot = new Plot(0,0,1,1);
	}
	/**
	Class constructor with object parameters
	* @param p property object
	*/
	public Property(Property p) {
		this.city = p.city;
		this.owner = p.owner;
		this.propertyName = p.propertyName;
		this.rentAmount = p.rentAmount;
		this.plot = p.plot;
	}
	
	/**
	Class constructor with parameters
	* @param propertyName
   * @param city
   * @param rentAmount
   * @param owner
	*/
	public Property(String propertyName, String city, double rentAmount, String owner) {
		this.propertyName = propertyName;
		this.city = city;
		this.rentAmount = rentAmount;
		this.owner = owner;
	}
	
	/**
	Class constructor with parameters for property and plot
	* @param propertyName
   * @param city
   * @param rentAmount
   * @param owner
   * @param x
   * @param y
   * @param width
   * @param depth
	*/
	public Property(String propertyName, String city, double rentAmount, String owner, int x, int y, int width, int depth) {
		this.propertyName = propertyName;
		this.city = city;
		this.rentAmount = rentAmount;
		this.owner = owner;
		this.plot = new Plot(x, y, width, depth);
	}
	
	/**
	Getter for city of the property
	* @return city city of property
	*/
	public String getCity() {
		return city;
	}
	
	/**
	Getter for the owner of the property
	* @return owner owner of property
	*/
	public String getOwner() {
		return owner;
	}
	
	/**
	Getter for the owner of the property
	* @return owner owner of property
	*/
	public String getPropertyName() {
		return propertyName;
	}
	
	/**
	Getter for the amount of the property
	* @return getRentAmount amount of the property
	*/
	public double getRentAmount () {
		return rentAmount;
	}
	
	/**
	Getter for the plot
	* @return plot 
	*/
	public Plot getPlot() {
		return plot;
	}
	
	/**
	Setter for plot position and size
	* @param x x position
	* @param x
    * @param y
    * @param width
    * @param depth
	*/
	public void setPlot(int x, int y, int width, int depth) {
		this.plot = new Plot(x, y, width, depth);
	}
	
	/**
	Setter for plot position and size
	* @param city city of property
	*/
	public void setCity(String city) {
		this.city = city;
	}
	
	/**
	Setter for the owner of the property
	* @param owner owner of property
	*/
	public void setOwner(String owner) {
		this.owner = owner;
	}
	
	/**
	Setter for the name of the property
	* @param name name of property
	*/
	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}
	
	/**
	Setter for the rent amount of the property
	* @param rentAmount rent of property
	*/
	public void setRentAmount(double rentAmount) {
		this.rentAmount = rentAmount;
	}
	
	public String toString() {
		return "Property Name: " + propertyName  + "\n" + "Located in " + city + "\n" + "Belonging to: " + owner
				+ "\n" + "Rent Amount: " + rentAmount + " ";
	}

}

